#' @title get data of adcusum
#' 
#' @description Get parameter of the function adcusum
#' 
#' @param data the response vector
#' @param n the variable vector that needs to calculate
#' @param r1 the rate of initial
#' @param r2 the rate of need to be tested
#' @return get the function's parameter
getDate2 <- function(data, n,r1,r2) {
  data
  n
  r1
  r2
}
