#' @title get data of adcusum_W
#' 
#' @description Get parameter of the function adcusum_W
#' 
#' @param data the response vector
#' @param n the variable vector that needs to calculate
#' @param rate the wight of c(last time)
#' @param r1 the rate of initial
#' @param r2 the rate of need to be tested
#' @return get the function's parameter
getDate3 <- function(data,n,rate,r1,r2) {
  data
  n
  rate
  r1
  r2
}
