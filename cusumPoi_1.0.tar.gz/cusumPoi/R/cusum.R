#' @title get date of cusum
#' 
#' @description Get parameter of the function cusum
#' 
#' @param data the response vector
#' @param n the fixed vector that needs to calculate
#' @param r1 the rate of initial
#' @param r2 the rate of need to be tested
#' @return get the function's parameter
getDate <- function(data, n,r1,r2) {
  data
  n
  r1
  r2
}
