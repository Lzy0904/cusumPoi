#' @title get_h_ad
#' 
#' @description Get minimum h that keeps no alarms in some steps
#' 
#' @param n the variable vector that needs to calculate
#' @param r1 the rate of initial
#' @param r2 the rate of need to be tested
#' @param aimar10 the alarm given
#' @param runtimes the steps given
#' @return the function's result h
get_h_ad <- function(n,r1,r2,aimarl0,runtimes){
  arl0=0
  h0=0
  while(arl0<aimarl0){
    m<-tempfunc3(n,r1,r2,runtimes,h0)
    arl0=mean(m)
    if (arl0>=aimarl0)
      h0 = h0
    if(arl0<aimarl0)
      h0 = h0 +0.001
  }
  return(h0)
}