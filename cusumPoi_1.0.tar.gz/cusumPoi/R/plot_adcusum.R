#' @title plotadcusum
#' 
#' @description draw a graph of adcusum
#' 
#' @param data the response vector
#' @param n the variable vector that needs to calculate
#' @param r1 the rate of initial
#' @param r2 the rate of need to be tested
#' @param year the time of data
#' @return a graph of adcusum
plotadcusum <- function(data,n,r1,r2,year){
  plot(
    x = year,
    y = adcusum(data,n,r1,r2),
    type = "o",
    pch = 20,
    xlim = c(min(year), max(year)),
    ylim = c(0, max(adcusum(data,n,r1,r2))),
    ylab = expression(ADCUSUM), xlab = "t",
  )
}
