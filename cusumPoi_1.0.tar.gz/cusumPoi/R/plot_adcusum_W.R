#' @title plotadcusum_W
#' 
#' @description draw a graph of adcusum_W
#' 
#' @param data the response vector
#' @param n the variable vector that needs to calculate
#' @param rate the wight of c(last time)
#' @param r1 the rate of initial
#' @param r2 the rate of need to be tested
#' @param year the time of data
#' @return a graph of adcusum_W
plotadcusum_W <- function(data,n,rate,r1,r2,year){
  plot(
    x = year,
    y = adcusum_W(data,n,rate,r1,r2),
    type = "o",
    pch = 20,
    xlim = c(min(year), max(year)),
    ylim = c(0, max(adcusum_W(data,n,rate,r1,r2))),
    ylab = expression(ADCUSUM_W), xlab = "t",
  )
}
