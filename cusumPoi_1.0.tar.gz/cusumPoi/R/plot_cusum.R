#' @title plotcusum
#' 
#' @description draw a graph of cusum
#' 
#' @param data the response vector
#' @param n the fixed number that needs to calculate
#' @param r1 the rate of initial
#' @param r2 the rate of need to be tested
#' @param year the time of data
#' @return a graph of cusum
plotcusum <- function(data,n,r1,r2,year){
  plot(
    x = year,
    y = cusum(data,n,r1,r2),
    type = "o",
    pch = 20,
    xlim = c(min(year), max(year)),
    ylim = c(0, max(cusum(data,n,r1,r2))),
    ylab = expression(CUSUM), xlab = "t",
  )
}
