tempfunc1<-function(n1,r1,r2){
  {
    y1<-unlist(lapply(n1*r1, rpois, n=1))
    c<-log(r2/r1)*(y1/n1-(r2-r1)/(log(r2)-log(r1)))
  }
  return(c)
}