tempfunc3_W<-function(n,rho,r1,r2,k,h){
  j=seq(1,k,1)
  arl=rep(0,k)
  for(x in j){
    u=mapply(tempfunc1, n, r1,r2)
    r=0
    i=0
    for(o in u){
      i = i+1
      b = max(0,o+rho*r)
      r=b
      if(r>h)
        break
    }
    arl[x]=i
  }
  return(arl)
}