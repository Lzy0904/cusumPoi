#include "RcppArmadillo.h"
// [[Rcpp::depends(RcppArmadillo)]]

#include <Rcpp.h>
#include <cmath>
#include <iostream>
#include <vector>
using namespace Rcpp;
using namespace std;
int n;
float pi1 = 0;
float pi2 = 0;
// [[Rcpp::export]]
float get_r(arma::vec data,int n){
  pi1 = (data[0]+data[1]+data[2])/3/n;
  pi2 = pi1*1.05;
  return pi1;
}
//' @title cusum
//' 
//' @description A statistical method that uses current and recent process data to examine small changes or variability in process averages. CUSUM stands for "cumulative sum" of deviation from target values. It gives equal weight to current and recent data.
//' 
//' @param data the response vector
//' @param n the fixed number that needs to calculate
//' @param r1 the rate of initial
//' @param r2 the rate of needs to test
//' @return a vector of bias
// [[Rcpp::export]]
arma::vec cusum(arma::vec data, int n, float r1, float r2) {
  float C = 0;
  int a = data.size();
  arma::vec timeseries(a, arma::fill::zeros);
  for (int i = 0; i < data.size(); i++) {
    float b = (C + log(r2 / r1) * (data[i] - n * (r2 - r1) / log(r2 / r1)));
    if (b < 0) {
      C = 0;
      timeseries(i) = C;
    }
    else {
      C = b;
      timeseries(i) = C;
    }
  }
  return timeseries;
}

//' @title adcusum
//' 
//' @description A statistical method that uses current and recent process data to examine small changes or variability in process averages. CUSUM stands for "cumulative sum" of deviation from target values. It gives equal weight to current and recent data.
//' 
//' @param data the response vector
//' @param n the variable vector that needs to calculate
//' @param r1 the rate of initial
//' @param r2 the rate of needs to test
//' @return a vector of bias
// [[Rcpp::export]]
arma::vec adcusum(arma::vec data, arma::vec n, float r1, float r2) {
  float C = 0;
  int a = data.size();
  arma::vec timeseries(a, arma::fill::zeros);
  for (int i = 0; i < data.size(); i++) {
    float b = (C + log(r2 / r1) * (data[i] / n[i] - (r2 - r1) / log(r2 / r1)));
    if (b < 0) {
      C = 0;
      timeseries(i) = C;
    }
    else {
      C = b;
      timeseries(i) = C;
    }
  }
  return timeseries;
}
//' @title adcusum_w
//' 
//' @description A statistical method that uses current and recent process data to examine small changes or variability in process averages. CUSUM stands for "cumulative sum" of deviation from target values. It gives equal weight to current and recent data.
//' 
//' @param data the response vector
//' @param n the variable vector that needs to calculate
//' @param rate the wight of c(last time)
//' @param r1 the rate of initial
//' @param r2 the rate of needs to test
//' @return a vector of bias
// [[Rcpp::export]]
arma::vec adcusum_W(arma::vec data, arma::vec n, float rate,float r1, float r2) {
  float C = 0;
  int a = data.size();
  arma::vec timeseries(a, arma::fill::zeros);
  for (int i = 0; i < data.size(); i++) {
    float b = (C*rate + log(r2 / r1) * (data[i] / n[i] - (r2 - r1) / log(r2 / r1)));
    if (b < 0) {
      C = 0;
      timeseries(i) = C;
    }
    else {
      C = b;
      timeseries(i) = C;
    }
  }
  return timeseries;
}
